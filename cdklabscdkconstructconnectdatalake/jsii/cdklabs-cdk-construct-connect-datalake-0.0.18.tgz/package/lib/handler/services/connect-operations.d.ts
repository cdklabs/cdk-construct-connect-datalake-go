import { AnalyticsDataAssociationResult, ConnectClient } from "@aws-sdk/client-connect";
import { ExecutionResult } from "../types/execution-result";
/**
 * Result of dataset association operations
 */
export interface AssociationResult {
    /**
     * Array of successfully created dataset associations
     */
    Created: AnalyticsDataAssociationResult[];
    /**
     * Array of errors encountered during association
     */
    Errors: Array<{
        /**
         * Identifier of the resource that failed
         */
        resourceId: string;
        /**
         * Error message describing the failure
         */
        error: string;
    }>;
}
/**
 * Associates analytics datasets for a Connect instance with the target account
 *
 * @param instanceId - Connect instance ID
 * @param datasetIds - Array of dataset IDs to associate
 * @param targetAccountId - Target account ID for the associations
 * @param connectClient - Connect client instance
 * @returns AssociationResult
 */
export declare function batchAssociateAnalyticsDatasets(instanceId: string, datasetIds: string[], targetAccountId: string, connectClient: ConnectClient): Promise<AssociationResult>;
/**
 * Disassociates analytics datasets that are associated with a Connect instance
 *
 * @param instanceId - Connect instance ID
 * @param datasetIds - Array of dataset IDs to disassociate
 * @param targetAccountId - Target account ID where datasets are associated
 * @param connectClient - Connect client instance
 * @returns ExecutionResult
 */
export declare function batchDisassociateAnalyticsDatasets(instanceId: string, datasetIds: string[], targetAccountId: string, connectClient: ConnectClient): Promise<ExecutionResult>;
/**
 * Lists all available analytics data lake datasets for a Connect instance
 *
 * @param instanceId - Connect instance ID
 * @param connectClient - Connect client instance
 * @returns Set of valid connect analytics dataset IDs
 */
export declare function listAnalyticsDataLakeDataSets(instanceId: string, connectClient: ConnectClient): Promise<Set<string>>;
/**
 * Lists all dataset associations grouped by instance for a target account
 *
 * @param connectClient - Connect client instance
 * @param targetAccountId - Target account ID to filter associations
 * @returns Map of instance IDs to their associated dataset IDs
 */
export declare function listAllAnalyticsDataAssociations(connectClient: ConnectClient, targetAccountId: string): Promise<Map<string, string[]>>;
