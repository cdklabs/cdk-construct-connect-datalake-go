import { AnalyticsDataAssociationResult } from "@aws-sdk/client-connect";
import { RAMClient } from "@aws-sdk/client-ram";
/**
 * Result of RAM invitation acceptance operations
 */
export interface RamResult {
    /**
     * Map of accepted resource share ARNs to their associated dataset IDs
     */
    acceptedInvitations: Map<string, string[]>;
    /**
     * Optional map of expired resource share ARNs to their associated dataset IDs
     */
    expiredInvitations?: Map<string, string[]>;
    /**
     * Error message describing the failure
     */
    errors: string[];
}
/**
 * Accepts RAM invitations for dataset associations
 *
 * Groups datasets by resource share ARN and attempts to accept each invitation.
 * Handles expired invitations separately
 *
 * @param createdDatasets - Array of dataset association results from Connect
 * @param ramClient - RAM client instance
 * @returns RamResult
 */
export declare function acceptRamInvitations(createdDatasets: AnalyticsDataAssociationResult[], ramClient: RAMClient): Promise<RamResult>;
/**
 * Lists all RAM resource-shared Glue table names
 *
 * @param ramClient - RAM client instance
 * @returns Set of table names in format datasetId_dataCatalogId
 */
export declare function listRamSharedTables(ramClient: RAMClient): Promise<Set<string>>;
