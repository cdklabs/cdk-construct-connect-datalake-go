import { LakeFormationClient } from "@aws-sdk/client-lakeformation";
/**
 * Sets up Lake Formation admin permissions for the specified role
 *
 * @param roleArn - ARN of the role to grant permissions to
 * @param lakeformationClient - Lake Formation client instance
 */
export declare function setupLakeFormationPermissions(roleArn: string, lakeformationClient: LakeFormationClient): Promise<void>;
/**
 * Removes specified role from Lake Formation permissions
 *
 * @param roleArn - ARN of the role to remove permissions for
 * @param lakeformationClient - Lake Formation client instance
 */
export declare function removeLakeFormationPermissions(roleArn: string, lakeformationClient: LakeFormationClient): Promise<void>;
