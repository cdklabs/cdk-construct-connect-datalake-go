import { GlueClient } from "@aws-sdk/client-glue";
import { ExecutionResult } from "../types/execution-result";
/**
 * Creates a database in the Glue Data Catalog
 *
 * @param glueClient - Glue client instance
 */
export declare function createGlueDatabase(glueClient: GlueClient): Promise<void>;
/**
 * Deletes a database from the Glue Data Catalog
 *
 * @param glueClient - Glue client instance
 */
export declare function deleteGlueDatabase(glueClient: GlueClient): Promise<void>;
/**
 * Creates resource link tables for the given datasets
 *
 * @param datasetIds - Array of dataset IDs
 * @param sharedCatalogId - Catalog ID for the shared resource
 * @param glueClient - Glue client instance
 * @returns ExecutionResult
 */
export declare function createResourceLinkTables(datasetIds: string[], sharedCatalogId: string, glueClient: GlueClient): Promise<ExecutionResult>;
/**
 * Retrieves resource link table names that point to DATALAKE_DATABASE_NAME
 *
 * @param glueClient - Glue client instance
 * @returns Array of resource link table names
 */
export declare function getTableNames(glueClient: GlueClient): Promise<string[]>;
/**
 * Deletes a given set of resource link tables in the database
 *
 * @param glueClient - Glue client instance
 * @param targetTables - Set of dataset IDs to delete
 * @returns ExecutionResult
 */
export declare function deleteResourceLinkTables(glueClient: GlueClient, targetTables: Set<string>): Promise<ExecutionResult>;
