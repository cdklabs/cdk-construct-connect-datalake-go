import { CdkCustomResourceEvent } from "aws-lambda";
import { CustomResourceProperties } from "../types/custom-resource-properties";
import { CustomResourceResponse } from "../types/custom-resource-response";
/**
 * Handles DELETE operations for Connect Data Lake integration cleanup
 *
 * @param event -  CloudFormation custom resource DELETE event
 * @returns CustomResourceResponse
 */
export declare function onDelete(event: CdkCustomResourceEvent<CustomResourceProperties>): Promise<CustomResourceResponse>;
