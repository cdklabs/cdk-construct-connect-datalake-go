export declare const DATALAKE_DATABASE_NAME = "connect_datalake";
export declare const LAKE_FORMATION_DATABASE_NAME = "connect_datalake_database";
export declare const RAM_STABILIZATION_MS = 120000;
export declare enum ExpectedErrors {
    ENTITY_NOT_FOUND = "EntityNotFoundException",
    ALREADY_EXISTS = "AlreadyExistsException",
    RESOURCE_SHARE_INVITATION_ALREADY_ACCEPTED = "ResourceShareInvitationAlreadyAcceptedException",
    RESOURCE_SHARE_INVITATION_EXPIRED = "ResourceShareInvitationExpiredException",
    UNKNOWN_RESOURCE = "UnknownResourceException"
}
