import { Construct } from "constructs";
import { DataType } from "./data-types";
export * from "./data-types";
/**
 * Properties for the DataLakeAccess construct
 */
export interface DataLakeAccessProps {
    /**
     * The identifier of the Amazon Connect instance
     */
    readonly instanceId: string;
    /**
     * Array of dataset IDs to associate with the Connect instance
     *
     * Can include DataType enum values or string dataset IDs
     */
    readonly datasetIds: Array<string | DataType>;
    /**
     * The identifier of the target account
     *
     * If not specified, defaults to the current AWS account. For cross-account setups,
     * specify an external account ID to associate datasets and create resources in that account
     *
     * When specified with an external account, `targetAccountRoleArn` is also required
     */
    readonly targetAccountId?: string;
    /**
     * The IAM role ARN in the target account for cross-account role assumption
     *
     * Only required when `targetAccountId` is specified with an external account. A template
     * for the required permissions can be found in the [Cross Account Setup](../CROSS_ACCOUNT_SETUP.md) documentation
     */
    readonly targetAccountRoleArn?: string;
}
/**
 * Automates Amazon Connect Data Lake integration setup and management.
 *
 * This construct simplifies the process of associating Amazon Connect analytics datasets with AWS data lake services,
 * handling resource sharing, Lake Formation permissions, and data catalog management through a centralized Glue database.
 */
export declare class DataLakeAccess extends Construct {
    private static readonly DATABASE_NAME;
    /**
     * @param scope Parent to which the Custom Resource belongs
     * @param id Unique identifier for this instance
     * @param props Metadata for configuring the Custom Resource
     */
    constructor(scope: Construct, id: string, props: DataLakeAccessProps);
    /**
     * Validates the construct input parameters
     *
     * @param props The construct properties to validate
     * @param isCrossAccountDeployment Indicates if target account differs from current account
     */
    private validateProps;
    /**
     * Configures Lambda permissions for same-account or cross-account deployments
     *
     * @param lambdaFunction The Lambda function to configure permissions for
     * @param partition AWS partition for resource ARN construction
     * @param region AWS region for resource ARN construction
     * @param account Current account ID where the Connect instance resides
     * @param stackName Name of the CloudFormation stack
     * @param isCrossAccountDeployment Indicates if target account differs from current account
     * @param roleArn Role ARN used for cross-account deployments
     */
    private configureLambdaPermissions;
}
