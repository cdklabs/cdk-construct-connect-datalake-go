/**
 * CloudFormation response structure for custom resource operations
 */
export interface CustomResourceResponse {
    /** Status of the custom resource operation */
    Status: "SUCCESS" | "FAILED";
    /** Additional response data */
    Data: {
        /** Error message containing information for failed operations */
        errors: string;
    };
}
