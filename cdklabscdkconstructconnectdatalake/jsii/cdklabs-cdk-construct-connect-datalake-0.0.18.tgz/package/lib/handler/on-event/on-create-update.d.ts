import { CdkCustomResourceEvent } from "aws-lambda";
import { CustomResourceProperties } from "../types/custom-resource-properties";
import { CustomResourceResponse } from "../types/custom-resource-response";
/**
 * Handles CREATE and UPDATE operations for Connect Data Lake setup
 *
 * @param event - CloudFormation custom resource event
 * @returns CustomResourceResponse
 */
export declare function onCreateUpdate(event: CdkCustomResourceEvent<CustomResourceProperties>): Promise<CustomResourceResponse>;
