import { ConnectClient } from "@aws-sdk/client-connect";
import { GlueClient } from "@aws-sdk/client-glue";
import { LakeFormationClient } from "@aws-sdk/client-lakeformation";
import { RAMClient } from "@aws-sdk/client-ram";
/**
 * AWS service clients for Connect data lake integration operations
 */
export interface AwsClients {
    /**
     * Amazon Connect client for managing Connect analytics dataset associations
     * */
    connect: ConnectClient;
    /**
     * AWS Glue client for managing Glue Data Catalog databases and resource link tables
     * */
    glue: GlueClient;
    /**
     * Lake Formation client for managing data lake settings and permissions
     * */
    lakeformation: LakeFormationClient;
    /**
     * Resource Access Manager client for accepting resource share invitations
     * */
    ram: RAMClient;
}
/**
 * Creates AWS service clients for source and target accounts
 *
 * @param lambdaAccountId - AWS account ID where Lambda is executing
 * @param targetAccountId - AWS account ID where resources will be created
 * @param roleArn - ARN of the role to assume for operations
 * @returns AwsClients
 */
export declare function createAwsClients(lambdaAccountId: string, targetAccountId: string, roleArn: string): Promise<AwsClients>;
