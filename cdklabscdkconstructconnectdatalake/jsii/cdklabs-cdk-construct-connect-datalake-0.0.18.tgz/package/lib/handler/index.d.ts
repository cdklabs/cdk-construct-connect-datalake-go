import { CdkCustomResourceEvent, CdkCustomResourceResponse, Context } from "aws-lambda";
import { CustomResourceProperties } from "./types/custom-resource-properties";
/**
 * Entry point
 * @param event Input provided to the custom resource
 * @param _context AWS Lambda context
 * @returns CdkCustomResourceResponse
 */
export declare function handler(event: CdkCustomResourceEvent<CustomResourceProperties>, _context: Context): Promise<CdkCustomResourceResponse>;
